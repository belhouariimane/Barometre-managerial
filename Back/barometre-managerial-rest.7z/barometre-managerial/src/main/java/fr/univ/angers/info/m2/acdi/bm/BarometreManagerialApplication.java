package fr.univ.angers.info.m2.acdi.bm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BarometreManagerialApplication {

	public static void main(String[] args) {
		SpringApplication.run(BarometreManagerialApplication.class, args);
	}

}
